#!/bin/bash
#
# NX6000 Voice API - Rollback de versão
# Reverte para a release anterior em caso de problema.
#
# Uso: sudo ./deploy/rollback.sh
#

set -e

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${YELLOW}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${YELLOW}║           NX6000 Voice - Rollback de Versão                  ║${NC}"
echo -e "${YELLOW}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Verificar se é root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}❌ Este script precisa ser executado como root (use sudo)${NC}"
    exit 1
fi

# Derivar configurações do package.json instalado
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_JSON="$SCRIPT_DIR/../package.json"
PACKAGE_NAME=$(node -p "require('$PACKAGE_JSON').name" 2>/dev/null || echo "nx6000-voice")
INSTALL_BASE="/opt/$PACKAGE_NAME"
RELEASES_DIR="$INSTALL_BASE/releases"
CURRENT_LINK="$INSTALL_BASE/current"
SERVICE_NAME="$PACKAGE_NAME"

# Verificar se o diretório de releases existe
if [ ! -d "$RELEASES_DIR" ]; then
    echo -e "${RED}❌ Diretório de releases não encontrado: $RELEASES_DIR${NC}"
    exit 1
fi

# Verificar se o symlink existe
if [ ! -L "$CURRENT_LINK" ]; then
    echo -e "${RED}❌ Symlink atual não encontrado: $CURRENT_LINK${NC}"
    exit 1
fi

# Obter release atual
CURRENT_RELEASE=$(readlink "$CURRENT_LINK")
CURRENT_NAME=$(basename "$CURRENT_RELEASE")

echo -e "${BLUE}📦 Release atual:${NC} $CURRENT_NAME"
echo ""

# Listar releases disponíveis (ordenadas por data, mais recentes primeiro)
cd "$RELEASES_DIR"
RELEASES=($(ls -t))
RELEASES_COUNT=${#RELEASES[@]}

if [ $RELEASES_COUNT -lt 2 ]; then
    echo -e "${RED}❌ Apenas uma release disponível. Rollback não é possível.${NC}"
    echo "   É necessário ter pelo menos 2 releases para fazer rollback."
    exit 1
fi

echo -e "${YELLOW}📋 Releases disponíveis:${NC}"
for i in "${!RELEASES[@]}"; do
    RELEASE="${RELEASES[$i]}"
    if [ "$RELEASES_DIR/$RELEASE" = "$CURRENT_RELEASE" ]; then
        echo -e "   ${GREEN}[$i]${NC} $RELEASE ${GREEN}⬅ ATUAL${NC}"
    else
        echo "   [$i] $RELEASE"
    fi
done
echo ""

# Identificar release anterior (próxima na lista após a atual)
PREVIOUS_RELEASE=""
for i in "${!RELEASES[@]}"; do
    if [ "$RELEASES_DIR/${RELEASES[$i]}" = "$CURRENT_RELEASE" ]; then
        # Próximo índice é a release anterior
        NEXT_INDEX=$((i + 1))
        if [ $NEXT_INDEX -lt $RELEASES_COUNT ]; then
            PREVIOUS_RELEASE="${RELEASES[$NEXT_INDEX]}"
            break
        fi
    fi
done

if [ -z "$PREVIOUS_RELEASE" ]; then
    echo -e "${RED}❌ Não foi possível identificar a release anterior.${NC}"
    exit 1
fi

echo -e "${BLUE}🔄 Release para rollback:${NC} $PREVIOUS_RELEASE"
echo ""

# Confirmar rollback
read -p "$(echo -e ${YELLOW}Deseja fazer rollback para a versão anterior? \(S/n\)${NC} )" -n 1 -r
echo
if [[ $REPLY =~ ^[Nn]$ ]]; then
    echo -e "${YELLOW}❌ Rollback cancelado${NC}"
    exit 0
fi

# Parar serviço
echo ""
echo -e "${YELLOW}▶ Parando serviço...${NC}"
if systemctl is-active --quiet "$SERVICE_NAME"; then
    systemctl stop "$SERVICE_NAME"
    echo -e "${GREEN}✓ Serviço parado${NC}"
else
    echo "   Serviço já está parado"
fi
echo ""

# Fazer backup do symlink atual
BACKUP_LINK="${CURRENT_LINK}.backup"
if [ -L "$CURRENT_LINK" ]; then
    cp -P "$CURRENT_LINK" "$BACKUP_LINK"
    echo -e "${YELLOW}▶ Backup do symlink criado${NC}"
fi

# Atualizar symlink
echo -e "${YELLOW}▶ Atualizando symlink...${NC}"
rm -f "$CURRENT_LINK"
ln -s "$RELEASES_DIR/$PREVIOUS_RELEASE" "$CURRENT_LINK"
echo -e "${GREEN}✓ Symlink atualizado${NC}"
echo "   $CURRENT_LINK -> $RELEASES_DIR/$PREVIOUS_RELEASE"
echo ""

# Reiniciar serviço
echo -e "${YELLOW}▶ Reiniciando serviço...${NC}"
systemctl start "$SERVICE_NAME"
sleep 2

if systemctl is-active --quiet "$SERVICE_NAME"; then
    echo -e "${GREEN}✓ Serviço reiniciado com sucesso!${NC}"
    echo ""
    echo -e "${GREEN}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║                  ✅ ROLLBACK CONCLUÍDO                         ║${NC}"
    echo -e "${GREEN}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${BLUE}🔄 Versão anterior:${NC} $CURRENT_NAME"
    echo -e "${BLUE}📦 Versão atual:${NC} $PREVIOUS_RELEASE"
    echo ""
    echo -e "${YELLOW}📋 Verificar status:${NC}"
    echo "   systemctl status $SERVICE_NAME"
    echo "   journalctl -u $SERVICE_NAME -f"
    echo ""
    echo -e "${YELLOW}♻️  Desfazer rollback:${NC}"
    echo "   Para voltar à versão $CURRENT_NAME, execute novamente este script"
    echo ""
    echo -e "${YELLOW}🩺 Health check:${NC}"
    echo "   curl http://localhost:3000/health/cameras"
    echo ""
else
    echo -e "${RED}❌ Falha ao reiniciar serviço!${NC}"
    echo ""
    echo -e "${YELLOW}Restaurando symlink anterior...${NC}"
    if [ -L "$BACKUP_LINK" ]; then
        rm -f "$CURRENT_LINK"
        cp -P "$BACKUP_LINK" "$CURRENT_LINK"
        echo -e "${GREEN}✓ Symlink restaurado${NC}"
    fi
    echo ""
    echo -e "${RED}Verifique os logs:${NC} journalctl -u $SERVICE_NAME -n 50"
    exit 1
fi

# Remover backup do symlink
rm -f "$BACKUP_LINK"
