#!/bin/bash
#
# NX6000 Voice API - Desinstalação
# Remove completamente o serviço e arquivos instalados.
#
# Uso: sudo ./deploy/uninstall.sh
#

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${YELLOW}║           NX6000 Voice - Desinstalação do Sistema             ║${NC}"
echo -e "${YELLOW}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""

if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}❌ Este script precisa ser executado como root (use sudo)${NC}"
    exit 1
fi

# Derivar configurações do package.json instalado
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_JSON="$SCRIPT_DIR/../package.json"
PACKAGE_NAME=$(node -p "require('$PACKAGE_JSON').name" 2>/dev/null || echo "nx6000-voice")
SERVICE_NAME="$PACKAGE_NAME"
INSTALL_DIR="/opt/$PACKAGE_NAME"
SERVICE_USER="nx6000"
LOG_DIR="/var/log/$PACKAGE_NAME"

echo -e "${RED}⚠️  ATENÇÃO: Esta operação irá remover:${NC}"
echo "   - Serviço systemd ($SERVICE_NAME)"
echo "   - Aplicação instalada ($INSTALL_DIR)"
echo "   - Logs ($LOG_DIR)"
echo "   - Usuário do sistema ($SERVICE_USER)"
echo ""

read -p "Tem certeza que deseja continuar? (digite 'sim' para confirmar): " -r
if [[ ! $REPLY == "sim" ]]; then
    echo -e "${YELLOW}Operação cancelada.${NC}"
    exit 0
fi

echo ""
echo -e "${YELLOW}▶ Iniciando desinstalação...${NC}"
echo ""

# 1. Parar e desabilitar serviço
if systemctl is-active --quiet "$SERVICE_NAME"; then
    echo "   Parando serviço..."
    systemctl stop "$SERVICE_NAME"
fi

if systemctl is-enabled --quiet "$SERVICE_NAME" 2>/dev/null; then
    echo "   Desabilitando serviço..."
    systemctl disable "$SERVICE_NAME"
fi

# 2. Remover arquivo de serviço
if [ -f "/etc/systemd/system/${SERVICE_NAME}.service" ]; then
    rm "/etc/systemd/system/${SERVICE_NAME}.service"
    systemctl daemon-reload
    echo -e "${GREEN}✓ Serviço systemd removido${NC}"
fi

# 3. Remover diretórios
if [ -d "$INSTALL_DIR" ]; then
    rm -rf "$INSTALL_DIR"
    echo -e "${GREEN}✓ Aplicação removida${NC}"
fi

if [ -d "$LOG_DIR" ]; then
    rm -rf "$LOG_DIR"
    echo -e "${GREEN}✓ Logs removidos${NC}"
fi

# 4. Remover usuário
if id "$SERVICE_USER" &>/dev/null; then
    userdel "$SERVICE_USER" 2>/dev/null || true
    echo -e "${GREEN}✓ Usuário removido${NC}"
fi

echo ""
echo -e "${GREEN}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                  ✅ DESINSTALAÇÃO CONCLUÍDA                    ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${GREEN}O NX6000 Voice foi completamente removido do sistema.${NC}"
