#!/bin/bash
#
# NX6000 Voice API - Instalação na Raspberry Pi
# Instala e configura a API de vocalização de textos como serviço systemd.
#
# Uso: sudo ./deploy/install.sh
# Execute do diretório raiz do pacote extraído.
#

set -e

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║         NX6000 Voice - Instalação na Raspberry Pi             ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Verificar se é root
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}❌ Este script precisa ser executado como root (use sudo)${NC}"
    exit 1
fi

# Configurações
PACKAGE_NAME=$(node -p "require('./package.json').name")
INSTALL_BASE="/opt/$PACKAGE_NAME"
RELEASES_DIR="$INSTALL_BASE/releases"
CURRENT_LINK="$INSTALL_BASE/current"
SERVICE_NAME="$PACKAGE_NAME"
SERVICE_USER="nx6000"
LOG_DIR="/var/log/$PACKAGE_NAME"
ENV_FILE="$INSTALL_BASE/.env"

# Versão do Node.js mínima requerida
NODE_MIN_VERSION="18.0.0"

# Detectar versão do pacote
RELEASE_VERSION=$(node -p "require('./package.json').version" 2>/dev/null || echo "unknown")
RELEASE_TIMESTAMP=$(date +%Y%m%d_%H%M%S)
RELEASE_NAME="${RELEASE_VERSION}-${RELEASE_TIMESTAMP}"
INSTALL_DIR="$RELEASES_DIR/$RELEASE_NAME"

echo -e "${YELLOW}📋 Configurações de instalação:${NC}"
echo "   Pacote:   $PACKAGE_NAME v$RELEASE_VERSION"
echo "   Release:  $RELEASE_NAME"
echo "   Diretório: $INSTALL_DIR"
echo "   Symlink:  $CURRENT_LINK"
echo "   Serviço:  $SERVICE_NAME"
echo "   Usuário:  $SERVICE_USER"
echo "   Logs:     $LOG_DIR"
echo "   Env:      $ENV_FILE"
echo ""

# Função para comparar versões
version_ge() {
    [ "$(printf '%s\n' "$1" "$2" | sort -V | head -n1)" = "$2" ]
}

# 1. Verificar Node.js
echo -e "${YELLOW}▶ Verificando Node.js...${NC}"
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js não encontrado!${NC}"
    echo "   Instale Node.js $NODE_MIN_VERSION ou superior"
    echo "   Exemplo: curl -fsSL https://deb.nodesource.com/setup_18.x | bash -"
    echo "            apt-get install -y nodejs"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2)
if version_ge "$NODE_VERSION" "$NODE_MIN_VERSION"; then
    echo -e "${GREEN}✓ Node.js v$NODE_VERSION detectado${NC}"
else
    echo -e "${RED}❌ Node.js v$NODE_VERSION é muito antigo (mínimo: v$NODE_MIN_VERSION)${NC}"
    exit 1
fi
echo ""

# 1b. Verificar alsa-utils (aplay) — obrigatório para reprodução com Piper
echo -e "${YELLOW}▶ Verificando alsa-utils (aplay)...${NC}"
if ! command -v aplay &> /dev/null; then
    echo -e "${YELLOW}⚠ 'aplay' não encontrado. Instalando alsa-utils...${NC}"
    apt-get install -y alsa-utils -qq
    echo -e "${GREEN}✓ alsa-utils instalado${NC}"
else
    echo -e "${GREEN}✓ aplay disponível${NC}"
fi
echo ""

# 1c. Instalar Piper e modelo em /opt/piper
echo -e "${YELLOW}▶ Preparando Piper TTS...${NC}"
if [ -x "./deploy/install-piper.sh" ]; then
    ./deploy/install-piper.sh
elif [ -f "./deploy/install-piper.sh" ]; then
    chmod +x ./deploy/install-piper.sh
    ./deploy/install-piper.sh
else
    echo -e "${RED}❌ Script deploy/install-piper.sh não encontrado no pacote.${NC}"
    exit 1
fi

if [ -x "/opt/piper/piper" ]; then
    echo -e "${GREEN}✓ piper instalado em /opt/piper/piper${NC}"
else
    echo -e "${RED}❌ Piper não foi instalado corretamente em /opt/piper.${NC}"
    exit 1
fi
echo ""

# 2. Criar usuário do serviço
echo -e "${YELLOW}▶ Configurando usuário do serviço...${NC}"
if id "$SERVICE_USER" &>/dev/null; then
    echo -e "${GREEN}✓ Usuário $SERVICE_USER já existe${NC}"
else
    useradd -r -s /bin/false -d "$INSTALL_DIR" "$SERVICE_USER"
    echo -e "${GREEN}✓ Usuário $SERVICE_USER criado${NC}"
fi

if getent group audio >/dev/null 2>&1; then
    usermod -aG audio "$SERVICE_USER"
    echo -e "${GREEN}✓ Usuário $SERVICE_USER adicionado ao grupo audio${NC}"
else
    echo -e "${YELLOW}⚠ Grupo 'audio' não encontrado. Verifique permissões ALSA em /dev/snd.${NC}"
fi
echo ""

# 3. Parar serviço existente (se houver)
echo -e "${YELLOW}▶ Verificando serviço existente...${NC}"
if systemctl is-active --quiet "$SERVICE_NAME"; then
    echo "   Parando serviço existente..."
    systemctl stop "$SERVICE_NAME"
    echo -e "${GREEN}✓ Serviço parado${NC}"
fi
echo ""

# 4. Criar diretórios
echo -e "${YELLOW}▶ Criando estrutura de diretórios...${NC}"
mkdir -p "$INSTALL_BASE"
mkdir -p "$RELEASES_DIR"
mkdir -p "$LOG_DIR"
mkdir -p "$INSTALL_DIR"
echo -e "${GREEN}✓ Diretórios criados${NC}"
echo ""

# 5. Copiar arquivos para a nova release
echo -e "${YELLOW}▶ Instalando aplicação (release: $RELEASE_NAME)...${NC}"
cp -r dist/ "$INSTALL_DIR/"
mkdir -p "$INSTALL_DIR/deploy"
cp deploy/install.sh deploy/install-piper.sh deploy/rollback.sh deploy/uninstall.sh "$INSTALL_DIR/deploy/"
chmod +x "$INSTALL_DIR/deploy/"*.sh
cp package.json "$INSTALL_DIR/"
cp package-lock.json "$INSTALL_DIR/" 2>/dev/null || true
echo -e "${GREEN}✓ Arquivos de aplicação copiados${NC}"
echo ""

# 6. Gerenciar node_modules (com reaproveitamento inteligente)
echo -e "${YELLOW}▶ Preparando dependências (node_modules)...${NC}"

# Detectar se existe release anterior via symlink
REUSE_MODULES=false
if [ -L "$CURRENT_LINK" ] && [ -e "$CURRENT_LINK" ]; then
    PREVIOUS_RELEASE=$(readlink "$CURRENT_LINK")
    echo "   Release anterior encontrada: $(basename $PREVIOUS_RELEASE)"
    
    # Comparar package.json e package-lock.json
    if [ -f "$PREVIOUS_RELEASE/package.json" ]; then
        if diff -q package.json "$PREVIOUS_RELEASE/package.json" >/dev/null 2>&1; then
            if [ ! -f package-lock.json ] || [ ! -f "$PREVIOUS_RELEASE/package-lock.json" ] || \
               diff -q package-lock.json "$PREVIOUS_RELEASE/package-lock.json" >/dev/null 2>&1; then
                echo "   ✓ package.json idêntico, reutilizando node_modules..."
                REUSE_MODULES=true
            fi
        fi
    fi
fi

if [ "$REUSE_MODULES" = true ] && [ -d "$PREVIOUS_RELEASE/node_modules" ]; then
    # Copiar node_modules da release anterior
    echo "   Copiando node_modules da release anterior (economiza tempo e banda)..."
    cp -a "$PREVIOUS_RELEASE/node_modules" "$INSTALL_DIR/"
    echo -e "${GREEN}✓ node_modules reutilizado da release anterior${NC}"
else
    # Instalar dependências do zero
    echo "   Instalando dependências no dispositivo (garante arquitetura correta)..."
    echo "   Isso pode levar alguns minutos dependendo da conexão..."
    
    cd "$INSTALL_DIR"
    if [ -f package-lock.json ]; then
        npm ci --production --quiet 2>&1 | grep -v "^npm WARN" || true
    else
        npm install --production --quiet 2>&1 | grep -v "^npm WARN" || true
    fi
    cd - > /dev/null
    
    echo -e "${GREEN}✓ Dependências instaladas (compiladas para $(uname -m))${NC}"
fi
echo ""

# 7. Atualizar symlink current
echo -e "${YELLOW}▶ Atualizando symlink...${NC}"
if [ -L "$CURRENT_LINK" ]; then
    PREVIOUS_RELEASE=$(readlink "$CURRENT_LINK")
    echo "   Release anterior: $PREVIOUS_RELEASE"
fi

# Remover symlink antigo se existir
rm -f "$CURRENT_LINK"

# Criar novo symlink
ln -s "$INSTALL_DIR" "$CURRENT_LINK"
echo -e "${GREEN}✓ Symlink atualizado: $CURRENT_LINK -> $INSTALL_DIR${NC}"
echo ""

# 8. Configurar arquivo .env
echo -e "${YELLOW}▶ Configurando variáveis de ambiente...${NC}"
if [ -f "$ENV_FILE" ]; then
    echo "   Arquivo .env já existe, mantendo configuração atual"
else
    if [ -f ".env.example" ]; then
        cp .env.example "$ENV_FILE"
    else
        cat > "$ENV_FILE" << EOF
PORT=3000
PIPER_BIN_DIR=/opt/piper
PIPER_MODEL=/opt/piper/pt_BR-faber-medium.onnx
APLAY_DEVICE=default
EOF
    fi
    echo -e "${YELLOW}   ⚠ Configure $ENV_FILE com PIPER_MODEL e, se necessário, PIPER_BIN_DIR/APLAY_DEVICE${NC}"
fi

# Link simbólico do .env para a release atual
ln -sf "$ENV_FILE" "$CURRENT_LINK/.env"
echo -e "${GREEN}✓ Configuração preparada${NC}"
echo ""

# 9. Configurar permissões
echo -e "${YELLOW}▶ Configurando permissões...${NC}"
chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_BASE"
chown -R "$SERVICE_USER:$SERVICE_USER" "$LOG_DIR"
chmod 640 "$ENV_FILE"
echo -e "${GREEN}✓ Permissões configuradas${NC}"
echo ""

# 10. Limpar releases antigas (manter apenas 2: atual + anterior)
echo -e "${YELLOW}▶ Limpando releases antigas...${NC}"
cd "$RELEASES_DIR"
RELEASES=($(ls -t))
RELEASES_COUNT=${#RELEASES[@]}

if [ $RELEASES_COUNT -gt 2 ]; then
    echo "   Encontradas $RELEASES_COUNT releases, removendo antigas..."
    for ((i=2; i<$RELEASES_COUNT; i++)); do
        OLD_RELEASE="${RELEASES[$i]}"
        echo "   Removendo: $OLD_RELEASE"
        rm -rf "$RELEASES_DIR/$OLD_RELEASE"
    done
    echo -e "${GREEN}✓ Releases antigas removidas (mantidas: 2)${NC}"
else
    echo "   Apenas $RELEASES_COUNT release(s), nenhuma remoção necessária"
fi
echo ""

# 11. Instalar serviço systemd
echo -e "${YELLOW}▶ Instalando serviço systemd...${NC}"
cat > "/etc/systemd/system/${SERVICE_NAME}.service" << EOF
[Unit]
Description=NX6000 Voice API
After=network.target
Wants=network-online.target

[Service]
Type=simple
User=$SERVICE_USER
Group=$SERVICE_USER
SupplementaryGroups=audio
WorkingDirectory=$CURRENT_LINK
Environment=NODE_ENV=production
EnvironmentFile=$ENV_FILE
ExecStart=/usr/bin/node $CURRENT_LINK/dist/server.js
Restart=always
RestartSec=10
StandardOutput=append:$LOG_DIR/${SERVICE_NAME}.log
StandardError=append:$LOG_DIR/${SERVICE_NAME}-error.log

# Security
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=$LOG_DIR

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
echo -e "${GREEN}✓ Serviço systemd instalado${NC}"
echo ""

# 12. Habilitar e iniciar serviço
echo -e "${YELLOW}▶ Habilitando serviço...${NC}"
systemctl enable "$SERVICE_NAME"
echo -e "${GREEN}✓ Serviço habilitado para iniciar no boot${NC}"
echo ""

# 12. Pergunta se deve iniciar agora
read -p "Deseja iniciar o serviço agora? (S/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Nn]$ ]]; then
    systemctl start "$SERVICE_NAME"
    sleep 2
    
    if systemctl is-active --quiet "$SERVICE_NAME"; then
        echo -e "${GREEN}✓ Serviço iniciado com sucesso!${NC}"
    else
        echo -e "${RED}❌ Falha ao iniciar serviço${NC}"
        echo "   Verifique os logs: journalctl -u $SERVICE_NAME -n 50"
        exit 1
    fi
fi

# 13. Informações finais
echo ""
echo -e "${GREEN}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                    ✅ INSTALAÇÃO CONCLUÍDA                     ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${YELLOW}📦 Release instalada:${NC} $RELEASE_NAME"
echo -e "${YELLOW}🔗 Symlink atual:${NC} $CURRENT_LINK -> $INSTALL_DIR"
echo ""
echo -e "${YELLOW}📋 Comandos úteis:${NC}"
echo "   Status:    systemctl status $SERVICE_NAME"
echo "   Iniciar:   systemctl start $SERVICE_NAME"
echo "   Parar:     systemctl stop $SERVICE_NAME"
echo "   Reiniciar: systemctl restart $SERVICE_NAME"
echo "   Logs:      journalctl -u $SERVICE_NAME -f"
echo "   Logs file: tail -f $LOG_DIR/${SERVICE_NAME}.log"
echo "   Rollback:  sudo $INSTALL_DIR/deploy/rollback.sh"
echo ""
echo -e "${YELLOW}📂 Diretórios importantes:${NC}"
echo "   Aplicação: $CURRENT_LINK (symlink)"
echo "   Releases:  $RELEASES_DIR"
echo "   Env:       $ENV_FILE"
echo "   Logs:      $LOG_DIR"
echo ""
echo -e "${YELLOW}⚠️  IMPORTANTE:${NC}"
echo "   1. Configure $ENV_FILE com PIPER_MODEL (e APLAY_DEVICE se necessário)"
echo "   2. Após alterar .env, reinicie: systemctl restart $SERVICE_NAME"
echo "   3. Health check: curl http://localhost:3000/health"
echo "   4. Em caso de problema: sudo $INSTALL_DIR/deploy/rollback.sh"
echo ""
echo -e "${GREEN}✅ Instalação finalizada com sucesso!${NC}"
