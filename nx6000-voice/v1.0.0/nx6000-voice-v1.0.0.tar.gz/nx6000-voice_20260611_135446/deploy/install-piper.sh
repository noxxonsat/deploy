#!/bin/bash
#
# Instala Piper em /opt/piper e baixa modelo para o mesmo diretório.
#
# Variáveis opcionais:
#   PIPER_INSTALL_DIR (default: /opt/piper)
#   PIPER_RELEASE_TAG (default: v1.2.0)
#   PIPER_ARCHIVE_NAME (default: piper_arm64.tar.gz)
#   PIPER_VOICE_MODEL (default: pt_BR-faber-medium)
#   PIPER_VOICE_BASE_URL (default: https://huggingface.co/rhasspy/piper-voices/resolve/main/pt/pt_BR/faber/medium)
#   FORCE_PIPER_REINSTALL (default: false)

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

PIPER_INSTALL_DIR="${PIPER_INSTALL_DIR:-/opt/piper}"
PIPER_RELEASE_TAG="${PIPER_RELEASE_TAG:-v1.2.0}"
PIPER_ARCHIVE_NAME="${PIPER_ARCHIVE_NAME:-piper_arm64.tar.gz}"
PIPER_VOICE_MODEL="${PIPER_VOICE_MODEL:-pt_BR-faber-medium}"
PIPER_VOICE_BASE_URL="${PIPER_VOICE_BASE_URL:-https://huggingface.co/rhasspy/piper-voices/resolve/main/pt/pt_BR/faber/medium}"
FORCE_PIPER_REINSTALL="${FORCE_PIPER_REINSTALL:-false}"

PIPER_BINARY_URL="https://github.com/rhasspy/piper/releases/download/${PIPER_RELEASE_TAG}/${PIPER_ARCHIVE_NAME}"
MODEL_ONNX_URL="${PIPER_VOICE_BASE_URL}/${PIPER_VOICE_MODEL}.onnx?download=true"
MODEL_JSON_URL="${PIPER_VOICE_BASE_URL}/${PIPER_VOICE_MODEL}.onnx.json?download=true"
PIPER_BINARY_PATH="${PIPER_INSTALL_DIR}/piper"
MODEL_ONNX_PATH="${PIPER_INSTALL_DIR}/${PIPER_VOICE_MODEL}.onnx"
MODEL_JSON_PATH="${PIPER_INSTALL_DIR}/${PIPER_VOICE_MODEL}.onnx.json"

is_truthy() {
  case "${1}" in
    1|true|TRUE|yes|YES|y|Y|on|ON) return 0 ;;
    *) return 1 ;;
  esac
}

is_current_install_valid() {
  if [ ! -x "${PIPER_BINARY_PATH}" ] || [ ! -s "${MODEL_ONNX_PATH}" ] || [ ! -s "${MODEL_JSON_PATH}" ]; then
    return 1
  fi

  if command -v jq >/dev/null 2>&1; then
    jq . "${MODEL_JSON_PATH}" >/dev/null 2>&1 || return 1
  fi

  return 0
}

if [ "${EUID}" -ne 0 ]; then
  echo -e "${RED}❌ Este script precisa ser executado como root.${NC}"
  exit 1
fi

if ! command -v curl >/dev/null 2>&1; then
  echo -e "${YELLOW}⚠ curl não encontrado. Instalando...${NC}"
  apt-get update -qq
  apt-get install -y curl ca-certificates -qq
fi

if ! command -v tar >/dev/null 2>&1; then
  echo -e "${RED}❌ tar não encontrado no sistema.${NC}"
  exit 1
fi

if ! is_truthy "${FORCE_PIPER_REINSTALL}" && is_current_install_valid; then
  echo -e "${GREEN}✓ Piper já instalado e válido em ${PIPER_INSTALL_DIR}. Pulando reinstalação.${NC}"
  echo -e "${YELLOW}  Para forçar reinstalação: FORCE_PIPER_REINSTALL=true ./deploy/install-piper.sh${NC}"
  exit 0
fi

echo -e "${YELLOW}▶ Instalando Piper em ${PIPER_INSTALL_DIR}...${NC}"
mkdir -p "${PIPER_INSTALL_DIR}"

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "${TMP_DIR}"' EXIT

echo "   Baixando binário: ${PIPER_BINARY_URL}"
curl -fL "${PIPER_BINARY_URL}" -o "${TMP_DIR}/piper.tar.gz"

tar -xzf "${TMP_DIR}/piper.tar.gz" -C "${TMP_DIR}"

PIPER_SOURCE_DIR=""
for candidate_dir in "${TMP_DIR}"/*; do
  if [ -d "${candidate_dir}" ] && [ -x "${candidate_dir}/piper" ]; then
    PIPER_SOURCE_DIR="${candidate_dir}"
    break
  fi
done

if [ -z "${PIPER_SOURCE_DIR}" ]; then
  echo -e "${RED}❌ Não foi possível localizar o binário piper no arquivo baixado.${NC}"
  exit 1
fi

# Limpa conteúdos anteriores para evitar sobras incompatíveis entre versões.
find "${PIPER_INSTALL_DIR}" -mindepth 1 -maxdepth 1 -exec rm -rf {} +

# Copia o bundle completo (binário + bibliotecas .so + assets).
cp -a "${PIPER_SOURCE_DIR}/." "${PIPER_INSTALL_DIR}/"

chmod +x "${PIPER_INSTALL_DIR}/piper"

echo "   Baixando modelo: ${PIPER_VOICE_MODEL}"
curl -fL "${MODEL_ONNX_URL}" -o "${MODEL_ONNX_PATH}"
curl -fL "${MODEL_JSON_URL}" -o "${MODEL_JSON_PATH}"

if command -v jq >/dev/null 2>&1; then
  jq . "${MODEL_JSON_PATH}" >/dev/null
fi

if [ ! -x "${PIPER_INSTALL_DIR}/piper" ] || [ ! -s "${MODEL_ONNX_PATH}" ] || [ ! -s "${MODEL_JSON_PATH}" ]; then
  echo -e "${RED}❌ Falha na instalação do Piper/modelo.${NC}"
  exit 1
fi

if ! "${PIPER_INSTALL_DIR}/piper" --help >/dev/null 2>&1; then
  echo -e "${RED}❌ Piper instalado, mas falhou ao carregar bibliotecas compartilhadas.${NC}"
  echo -e "${YELLOW}   Verifique se o pacote baixado contém libpiper_phonemize.so.1 e outras libs.${NC}"
  exit 1
fi

echo -e "${GREEN}✓ Piper instalado: ${PIPER_INSTALL_DIR}/piper${NC}"
echo -e "${GREEN}✓ Bibliotecas do Piper disponíveis em: ${PIPER_INSTALL_DIR} (e ${PIPER_INSTALL_DIR}/lib, se existir)${NC}"
echo -e "${GREEN}✓ Modelo instalado: ${MODEL_ONNX_PATH}${NC}"
echo -e "${GREEN}✓ Config JSON: ${MODEL_JSON_PATH}${NC}"
