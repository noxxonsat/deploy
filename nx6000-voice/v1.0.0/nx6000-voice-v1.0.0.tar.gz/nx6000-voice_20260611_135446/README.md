# NX6000 Voice API

API REST em Node.js + TypeScript para vocalizacao de textos, com Piper como motor principal e fallback para engines nativas do Linux.

## Stack

- Node.js 18+
- TypeScript
- Express 5
- Piper TTS
- ALSA (`aplay`)

## Funcionalidades

- Endpoint de saúde `GET /health`
- Endpoint de vocalizacao `POST /api/v1/speak`
- Suporte a Piper com modelo configuravel por ambiente ou payload
- Fallback automatico para `spd-say`, `espeak` e `festival`

## Requisitos de Sistema (Linux)

- `node` e `npm`
- `aplay` (pacote `alsa-utils`)
- `piper` instalado no `PATH` ou em diretorio configurado
- Modelo `.onnx` e respectivo `.onnx.json`

## Configuracao

Copie o arquivo de exemplo e ajuste os valores:

```bash
cp .env.example .env
```

Variaveis principais:

- `PORT`: porta HTTP da API (padrao 3000)
- `PIPER_BIN_DIR`: diretorio onde esta o binario `piper` (ex.: `/usr/local/bin`)
- `PIPER_MODEL`: caminho completo do modelo `.onnx`
- `APLAY_DEVICE`: device ALSA para saida de audio (ex.: `plughw:1,0`)

Observacao avancada: o runtime tambem aceita `PIPER_BIN` (caminho completo para o executavel), caso voce prefira definir o binario diretamente.

## Scripts NPM

```bash
npm run dev      # modo desenvolvimento (ts-node-dev)
npm run check    # type-check sem gerar build
npm run build    # compila TypeScript para dist/
npm run start    # executa build em dist/server.js
npm run clean    # remove dist/, dist-bundle/ e out/
npm run pack     # gera pacote de deploy para Raspberry Pi
```

## Uso Local

```bash
npm install
npm run build
npm start
```

A API sobe em `http://localhost:3000` por padrao.

## Endpoints

### `GET /health`

Resposta esperada:

```json
{"status":"ok"}
```

### `POST /api/v1/speak`

Request body:

```json
{
  "text": "Mensagem de teste",
  "model": "/opt/nx6000-voice/models/pt_BR-faber-medium.onnx",
  "speaker": 0,
  "speed": 1,
  "voice": "pt"
}
```

Campos:

- `text` (obrigatorio): string com no maximo 500 caracteres
- `model` (opcional): sobrescreve `PIPER_MODEL`
- `speaker` (opcional): inteiro >= 0 para modelos multi-speaker
- `speed` (opcional): numero entre 0 e 2
- `voice` (opcional): usado em engines de fallback

Exemplo `curl`:

```bash
curl -X POST http://localhost:3000/api/v1/speak \
  -H "Content-Type: application/json" \
  -d '{"text":"Ola, sistema de voz funcionando!"}'
```

Resposta de sucesso:

```json
{"message":"Comando de vocalizacao recebido."}
```

## Troubleshooting Rapido

- Erro JSON do Piper com `last read: '<'`:
  - O arquivo `.onnx.json` provavelmente foi baixado como HTML. Baixe novamente com `curl -fL` e valide com `jq`.
- Erro de audio no `aplay`:
  - Defina `APLAY_DEVICE` (ex.: `plughw:1,0`) e teste manualmente com `aplay -D plughw:1,0 arquivo.wav`.
- Piper nao encontrado:
  - Ajuste `PIPER_BIN_DIR` (ou `PIPER_BIN`) e garanta permissao de execucao.

## Deploy

Os scripts de deploy para Raspberry Pi estao em `deploy/`.

Guia completo: veja `deploy/QUICKSTART.md`.
