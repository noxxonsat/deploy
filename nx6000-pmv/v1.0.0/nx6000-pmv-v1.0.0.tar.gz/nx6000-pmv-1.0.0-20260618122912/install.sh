#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Uso:
  sudo ./install.sh [opcoes]

Opcoes:
  --user <usuario>         Usuario que vai executar servidor HTTP e kiosk (padrao: linaro)
  --install-dir <caminho>  Diretorio de deploy (padrao: /opt/nx6000-pmv)
  --port <porta>           Porta HTTP para o app estatico (padrao: 3000)
  --playlist-url <url>     URL remota da playlist para sincronizacao local
  --playlist-sync-min <n>  Intervalo de sincronizacao da playlist em minutos (padrao: 5)
  --playlist-media-dir <d> Diretório das mídias baixadas (padrao: .playlist-media)
  --playlist-cache-file <f> Arquivo de cache da playlist (padrao: .playlist-cache.json)
  --app-name <nome>        Nome base da app/servico HTTP (padrao: nx6000-pmv)
  --http-service <nome>    Nome do servico HTTP no systemd (padrao: <app-name>-http.service)
  --install-kiosk-deps     Instala dependencias do kiosk via apt
  --skip-kiosk-service     Nao configura autologin no LightDM/autostart do kiosk
  -h, --help               Mostra esta ajuda
EOF
}

APP_USER="linaro"
INSTALL_DIR="/opt/nx6000-pmv"
PORT="3000"
PLAYLIST_URL="https://cms.noxxonsat.com.br/api/public/playlist/current"
PLAYLIST_SYNC_MIN="5"
PLAYLIST_MEDIA_DIR=".playlist-media"
PLAYLIST_CACHE_FILE=".playlist-cache.json"
APP_NAME="nx6000-pmv"
HTTP_SERVICE=""
SKIP_KIOSK_SERVICE="false"
INSTALL_KIOSK_DEPS="false"

detect_chromium_command() {
  if command -v chromium-browser >/dev/null 2>&1; then
    echo "chromium-browser"
    return 0
  fi

  if command -v chromium >/dev/null 2>&1; then
    echo "chromium"
    return 0
  fi

  return 1
}

detect_unclutter_command() {
  if command -v unclutter-xfixes >/dev/null 2>&1; then
    echo "unclutter-xfixes"
    return 0
  fi

  if command -v unclutter >/dev/null 2>&1; then
    echo "unclutter"
    return 0
  fi

  return 1
}

disable_stale_backports_repo() {
  local changed="false"
  local list_file

  for list_file in /etc/apt/sources.list /etc/apt/sources.list.d/*.list; do
    [[ -f "${list_file}" ]] || continue

    if grep -Eq '^[[:space:]]*deb(-src)?[[:space:]].*bullseye-backports' "${list_file}"; then
      sed -i -E 's|^([[:space:]]*deb(-src)?[[:space:]].*bullseye-backports.*)$|# disabled by nx6000-pmv install: \1|g' "${list_file}"
      changed="true"
    fi
  done

  [[ "${changed}" == "true" ]]
}

apt_update_resilient() {
  local update_log
  update_log="$(mktemp)"

  if apt-get update 2>&1 | tee "${update_log}"; then
    rm -f "${update_log}"
    return 0
  fi

  if grep -q 'no longer has a Release file' "${update_log}"; then
    echo "[WARN] Foi detectado repositorio APT sem Release file. Tentando desabilitar backports obsoleto..."

    if disable_stale_backports_repo; then
      if apt-get update; then
        rm -f "${update_log}"
        return 0
      fi
    fi
  fi

  echo "[ERRO] Falha ao executar apt-get update." >&2
  cat "${update_log}" >&2
  rm -f "${update_log}"
  exit 1
}

ensure_node_installed() {
  if command -v node >/dev/null 2>&1; then
    return 0
  fi

  echo "[INFO] Node.js nao encontrado. Instalando via NodeSource..."
  if ! command -v curl >/dev/null 2>&1; then
    echo "[INFO] curl nao encontrado. Instalando curl..."
    apt_update_resilient
    apt-get install -y curl ca-certificates gnupg
  fi

  # Configura repositorio NodeSource (20) para obter versao atualizada de Node.js.
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt_update_resilient
  apt-get install -y nodejs

  if ! command -v node >/dev/null 2>&1; then
    echo "[ERRO] Falha ao instalar Node.js automaticamente." >&2
    exit 1
  fi
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --user)
      APP_USER="$2"
      shift 2
      ;;
    --install-dir)
      INSTALL_DIR="$2"
      shift 2
      ;;
    --port)
      PORT="$2"
      shift 2
      ;;
    --playlist-url)
      PLAYLIST_URL="$2"
      shift 2
      ;;
    --playlist-sync-min)
      PLAYLIST_SYNC_MIN="$2"
      shift 2
      ;;
    --playlist-media-dir)
      PLAYLIST_MEDIA_DIR="$2"
      shift 2
      ;;
    --playlist-cache-file)
      PLAYLIST_CACHE_FILE="$2"
      shift 2
      ;;
    --app-name)
      APP_NAME="$2"
      shift 2
      ;;
    --http-service)
      HTTP_SERVICE="$2"
      shift 2
      ;;
    --install-kiosk-deps)
      INSTALL_KIOSK_DEPS="true"
      shift
      ;;
    --skip-kiosk-service)
      SKIP_KIOSK_SERVICE="true"
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "[ERRO] Opcao invalida: $1" >&2
      usage
      exit 1
      ;;
  esac
done

if [[ "$(id -u)" -ne 0 ]]; then
  echo "[ERRO] Rode este script com sudo/root." >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DIST_SRC="${SCRIPT_DIR}/dist"
KIOSK_SERVICE="${APP_NAME}-kiosk.service"
KIOSK_SCRIPT="${INSTALL_DIR}/kiosk-start.sh"
LIGHTDM_CONF_DIR="/etc/lightdm/lightdm.conf.d"
LIGHTDM_CONF_FILE="${LIGHTDM_CONF_DIR}/50-${APP_NAME}-autologin.conf"
RESTART_SCRIPT="${INSTALL_DIR}/restart.sh"
SERVER_DIR="${INSTALL_DIR}/server"
SERVER_SCRIPT="${SERVER_DIR}/server.js"
SERVER_BUILD_FILE="${SCRIPT_DIR}/server/server.js"
SERVER_PACKAGE_FILE="${SCRIPT_DIR}/server/package.json"
APP_URL="http://localhost:${PORT}"
SERVER_ENV_FILE="${INSTALL_DIR}/.env"

if [[ -z "${HTTP_SERVICE}" ]]; then
  HTTP_SERVICE="${APP_NAME}-http.service"
fi

if [[ "${HTTP_SERVICE}" != *.service ]]; then
  HTTP_SERVICE="${HTTP_SERVICE}.service"
fi

if ! id -u "${APP_USER}" >/dev/null 2>&1; then
  echo "[ERRO] Usuario '${APP_USER}' nao encontrado." >&2
  exit 1
fi

APP_HOME="$(getent passwd "${APP_USER}" | cut -d: -f6)"
if [[ -z "${APP_HOME}" || ! -d "${APP_HOME}" ]]; then
  echo "[ERRO] Nao foi possivel identificar HOME do usuario '${APP_USER}'." >&2
  exit 1
fi
XFCE_AUTOSTART_DIR="${APP_HOME}/.config/autostart"
XFCE_AUTOSTART_FILE="${XFCE_AUTOSTART_DIR}/${APP_NAME}-kiosk.desktop"

if [[ ! -d "${DIST_SRC}" ]]; then
  echo "[ERRO] Pasta dist nao encontrada em ${DIST_SRC}." >&2
  echo "Extraia o pacote gerado por deploy/pack.sh e rode o install dentro dele." >&2
  exit 1
fi

ensure_node_installed

if [[ ! -f "${SERVER_BUILD_FILE}" ]]; then
  echo "[ERRO] Bundle do server nao encontrado em ${SERVER_BUILD_FILE}." >&2
  exit 1
fi

if [[ ! -f "${SERVER_PACKAGE_FILE}" ]]; then
  echo "[ERRO] package.json do server nao encontrado em ${SERVER_PACKAGE_FILE}." >&2
  exit 1
fi

CHROMIUM_CMD=""
UNCLUTTER_CMD=""

if CHROMIUM_CMD="$(detect_chromium_command)"; then
  :
fi

if UNCLUTTER_CMD="$(detect_unclutter_command)"; then
  :
fi

echo "[1/8] Publicando build em ${INSTALL_DIR}"
mkdir -p "${INSTALL_DIR}"
rm -rf "${INSTALL_DIR}/current"
cp -R "${DIST_SRC}" "${INSTALL_DIR}/current"
rm -rf "${SERVER_DIR}"
mkdir -p "${SERVER_DIR}"
cp "${SERVER_BUILD_FILE}" "${SERVER_SCRIPT}"
cp "${SERVER_PACKAGE_FILE}" "${SERVER_DIR}/package.json"

echo "[2/8] Instalando dependencias de producao do server"
pushd "${SERVER_DIR}" >/dev/null
# O bundle de deploy eh CommonJS (server.js). Remove "type: module" para evitar
# que o Node trate server.js como ESM durante a execucao no equipamento.
node -e "const fs=require('fs');const p=JSON.parse(fs.readFileSync('package.json','utf8'));if(p.type==='module'){delete p.type;}if(!p.main){p.main='server.js';}fs.writeFileSync('package.json', JSON.stringify(p, null, 2));"
npm install --omit=dev --no-audit --no-fund
popd >/dev/null

cat > "${SERVER_ENV_FILE}" <<EOF
ROOT_DIR=current
HOST=0.0.0.0
PORT=${PORT}
PLAYLIST_URL=${PLAYLIST_URL}
PLAYLIST_SYNC_MIN=${PLAYLIST_SYNC_MIN}
PLAYLIST_MEDIA_DIR=${PLAYLIST_MEDIA_DIR}
PLAYLIST_CACHE_FILE=${PLAYLIST_CACHE_FILE}
EOF
cp "${SCRIPT_DIR}/kiosk-start.sh" "${KIOSK_SCRIPT}"
cp "${SCRIPT_DIR}/restart.sh" "${RESTART_SCRIPT}"
chown -R "${APP_USER}:${APP_USER}" "${INSTALL_DIR}"
chmod +x "${KIOSK_SCRIPT}" "${RESTART_SCRIPT}"

if [[ "${SKIP_KIOSK_SERVICE}" == "false" ]]; then
  if [[ "${INSTALL_KIOSK_DEPS}" == "true" ]]; then
    echo "[3/8] Instalando dependencias do kiosk"
    apt_update_resilient

    CHROMIUM_PKG=""
    if apt-cache show chromium-browser >/dev/null 2>&1; then
      CHROMIUM_PKG="chromium-browser"
    elif apt-cache show chromium >/dev/null 2>&1; then
      CHROMIUM_PKG="chromium"
    fi

    UNCLUTTER_PKG=""
    if apt-cache show unclutter-xfixes >/dev/null 2>&1; then
      UNCLUTTER_PKG="unclutter-xfixes"
    elif apt-cache show unclutter >/dev/null 2>&1; then
      UNCLUTTER_PKG="unclutter"
    fi

    packages=(xserver-xorg lightdm xfce4-session)
    if [[ -n "${CHROMIUM_PKG}" ]]; then
      packages+=("${CHROMIUM_PKG}")
    fi
    if [[ -n "${UNCLUTTER_PKG}" ]]; then
      packages+=("${UNCLUTTER_PKG}")
    fi

    apt-get install -y "${packages[@]}"

    if [[ -z "${CHROMIUM_CMD}" ]]; then
      if CHROMIUM_CMD="$(detect_chromium_command)"; then
        :
      fi
    fi

    if [[ -z "${UNCLUTTER_CMD}" ]]; then
      if UNCLUTTER_CMD="$(detect_unclutter_command)"; then
        :
      fi
    fi
  fi

  if ! command -v lightdm >/dev/null 2>&1; then
    echo "[ERRO] LightDM nao encontrado." >&2
    echo "Instale dependencias com --install-kiosk-deps ou manualmente e rode de novo." >&2
    exit 1
  fi

  if ! command -v xfce4-session >/dev/null 2>&1; then
    echo "[ERRO] xfce4-session nao encontrado." >&2
    echo "Instale dependencias com --install-kiosk-deps ou manualmente e rode de novo." >&2
    exit 1
  fi

  if [[ -z "${CHROMIUM_CMD}" ]]; then
    echo "[ERRO] Chromium nao encontrado (comandos testados: chromium-browser, chromium)." >&2
    echo "Instale dependencias com --install-kiosk-deps ou manualmente e rode de novo." >&2
    exit 1
  fi

  if [[ -z "${UNCLUTTER_CMD}" ]]; then
    echo "[ERRO] Unclutter nao encontrado (comandos testados: unclutter-xfixes, unclutter)." >&2
    echo "Instale dependencias com --install-kiosk-deps ou manualmente e rode de novo." >&2
    exit 1
  fi
fi

if [[ "${SKIP_KIOSK_SERVICE}" == "false" ]]; then
  echo "[4/8] Configurando autologin no LightDM e autostart no XFCE"
  mkdir -p "${LIGHTDM_CONF_DIR}"
  cat > "${LIGHTDM_CONF_FILE}" <<EOF
[Seat:*]
autologin-user=${APP_USER}
autologin-user-timeout=0
user-session=xfce
EOF

  mkdir -p "${XFCE_AUTOSTART_DIR}"
  cat > "${XFCE_AUTOSTART_FILE}" <<EOF
[Desktop Entry]
Type=Application
Version=1.0
Name=${APP_NAME} Kiosk
Comment=Inicia Chromium em modo kiosk para o painel
Exec=${KIOSK_SCRIPT}
Terminal=false
X-GNOME-Autostart-enabled=true
X-MATE-Autostart-enabled=true
OnlyShowIn=XFCE;
EOF
  chown -R "${APP_USER}:${APP_USER}" "${APP_HOME}/.config"

  # Remove configuracoes legadas de tty1/startx para evitar conflito com LightDM.
  rm -f /etc/systemd/system/getty@tty1.service.d/override.conf
  rmdir /etc/systemd/system/getty@tty1.service.d >/dev/null 2>&1 || true
fi

echo "[5/8] Instalando servico HTTP ${HTTP_SERVICE}"
cat > "/etc/systemd/system/${HTTP_SERVICE}" <<EOF
[Unit]
Description=ITXPT TD Node HTTP Server
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${APP_USER}
Group=${APP_USER}
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/env node ${SERVER_SCRIPT}
Restart=always
RestartSec=2
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF

echo "[6/8] Habilitando e reiniciando servico HTTP"
systemctl daemon-reload
systemctl enable "${HTTP_SERVICE}" >/dev/null 2>&1 || true
systemctl restart "${HTTP_SERVICE}"

if [[ "${SKIP_KIOSK_SERVICE}" == "false" ]]; then
  systemctl enable lightdm >/dev/null 2>&1 || true
fi

if [[ "${SKIP_KIOSK_SERVICE}" == "false" ]]; then
  echo "[7/8] Preparando script do kiosk"
  sed -i "s|__KIOSK_URL__|${APP_URL}|g" "${KIOSK_SCRIPT}"
  if [[ -n "${CHROMIUM_CMD}" ]]; then
    sed -i "s|__CHROMIUM_BIN__|${CHROMIUM_CMD}|g" "${KIOSK_SCRIPT}"
  fi
  if [[ -n "${UNCLUTTER_CMD}" ]]; then
    sed -i "s|__UNCLUTTER_BIN__|${UNCLUTTER_CMD}|g" "${KIOSK_SCRIPT}"
  fi

  echo "[7/8] Aplicando politica gerenciada do Chromium (TranslateEnabled=false)"
  mkdir -p /etc/chromium/policies/managed
  cat > /etc/chromium/policies/managed/translate.json <<'EOF'
{
  "TranslateEnabled": false
}
EOF
fi

if [[ "${SKIP_KIOSK_SERVICE}" == "false" ]]; then
  systemctl disable --now "${KIOSK_SERVICE}" >/dev/null 2>&1 || true
  rm -f "/etc/systemd/system/${KIOSK_SERVICE}"

  echo "[8/8] Recarregando e aplicando autologin no LightDM"
  systemctl daemon-reload
  systemctl restart lightdm
else
  echo "[8/8] Configuracao do kiosk ignorada (--skip-kiosk-service)"
  echo "[8/8] Reiniciando apenas ${HTTP_SERVICE}"
  systemctl restart "${HTTP_SERVICE}" >/dev/null 2>&1 || true
fi

echo
echo "Instalacao concluida."
echo "App: ${APP_NAME}"
echo "URL local: ${APP_URL}"
echo "Diretorio: ${INSTALL_DIR}/current"
echo "HTTP service: ${HTTP_SERVICE}"
if [[ "${SKIP_KIOSK_SERVICE}" == "false" ]]; then
  echo "Kiosk startup: LightDM autologin (${APP_USER}) + autostart XFCE (${XFCE_AUTOSTART_FILE})"
fi
