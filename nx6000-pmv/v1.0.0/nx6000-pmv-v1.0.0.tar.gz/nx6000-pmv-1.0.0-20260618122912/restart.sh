#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Uso:
  sudo ./restart.sh [opcoes]

Opcoes:
  --app-name <nome>           Nome base da app/servico HTTP (padrao: itxpt-td-node)
  --user <usuario>            Usuario da sessao kiosk/autologin (padrao: pi)
  --http-service <nome>       Nome do servico HTTP (padrao: <app-name>-http.service)
  --skip-kiosk                Nao recicla sessao kiosk (tty1)
  -h, --help                  Mostra esta ajuda
EOF
}

APP_NAME="itxpt-td-node"
APP_USER="pi"
HTTP_SERVICE=""
SKIP_KIOSK="false"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --app-name)
      APP_NAME="$2"
      shift 2
      ;;
    --user)
      APP_USER="$2"
      shift 2
      ;;
    --http-service)
      HTTP_SERVICE="$2"
      shift 2
      ;;
    --skip-kiosk)
      SKIP_KIOSK="true"
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "[ERRO] Opcao invalida: $1" >&2
      usage
      exit 1
      ;;
  esac
done

if [[ "$(id -u)" -ne 0 ]]; then
  echo "[ERRO] Rode com sudo/root." >&2
  exit 1
fi

if [[ -z "${HTTP_SERVICE}" ]]; then
  HTTP_SERVICE="${APP_NAME}-http.service"
fi

if [[ "${HTTP_SERVICE}" != *.service ]]; then
  HTTP_SERVICE="${HTTP_SERVICE}.service"
fi

echo "[1/2] Reiniciando servico HTTP: ${HTTP_SERVICE}"
systemctl restart "${HTTP_SERVICE}"

if [[ "${SKIP_KIOSK}" == "false" ]]; then
  echo "[2/2] Reciclando sessao kiosk no tty1 (autologin/startx)"
  pkill -KILL -u "${APP_USER}" -f 'kiosk-start.sh|startx|xinit|chromium-browser|chromium|openbox-session|unclutter-xfixes|unclutter' >/dev/null 2>&1 || true
  pkill -KILL -f '^/usr/lib/xorg/Xorg .* :0' >/dev/null 2>&1 || true
  APP_HOME="$(getent passwd "${APP_USER}" | cut -d: -f6)"
  if [[ -n "${APP_HOME}" && -d "${APP_HOME}" ]]; then
    rm -rf "${APP_HOME}/.config/chromium-kiosk-profile/Default/Service Worker" \
           "${APP_HOME}/.config/chromium-kiosk-profile/Default/Cache" \
           "${APP_HOME}/.config/chromium-kiosk-profile/Default/Code Cache" \
           "${APP_HOME}/.config/chromium-kiosk-profile/Default/Session Storage" \
           "${APP_HOME}/.config/chromium-kiosk-profile/ShaderCache" \
           "${APP_HOME}/.config/chromium-kiosk-profile/GrShaderCache" \
           "${APP_HOME}/.config/chromium-kiosk-profile/GPUCache" >/dev/null 2>&1 || true
  fi
  rm -f /tmp/.X0-lock /tmp/.X11-unix/X0 >/dev/null 2>&1 || true
  systemctl restart getty@tty1
else
  echo "[2/2] Kiosk ignorado (--skip-kiosk)"
fi

echo "Restart concluido."
