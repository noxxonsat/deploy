#!/usr/bin/env bash
set -euo pipefail

# Script pensado para iniciar via autostart da sessao LightDM/XFCE.
# Mantemos fallbacks para ambiente grafico e runtime dir.
if [[ -z "${XDG_RUNTIME_DIR:-}" ]]; then
  export XDG_RUNTIME_DIR="/run/user/$(id -u)"
fi
mkdir -p "${XDG_RUNTIME_DIR}"
chmod 700 "${XDG_RUNTIME_DIR}" || true

if [[ -z "${DISPLAY:-}" ]]; then
  echo "[WARN] DISPLAY nao definido; usando fallback :0" >&2
  export DISPLAY=":0"
fi

if [[ -z "${DBUS_SESSION_BUS_ADDRESS:-}" && -S "${XDG_RUNTIME_DIR}/bus" ]]; then
  export DBUS_SESSION_BUS_ADDRESS="unix:path=${XDG_RUNTIME_DIR}/bus"
fi

PROFILE_DIR="$HOME/.config/chromium-kiosk-profile"
APP_URL="__KIOSK_URL__"
CHROMIUM_BIN="__CHROMIUM_BIN__"
UNCLUTTER_BIN="__UNCLUTTER_BIN__"

# Remove stale local caches from previous releases (especially old PWA SW state).
rm -rf "${PROFILE_DIR}/Default/Service Worker" \
  "${PROFILE_DIR}/Default/Cache" \
  "${PROFILE_DIR}/Default/Code Cache" \
  "${PROFILE_DIR}/Default/Session Storage" \
  "${PROFILE_DIR}/ShaderCache" \
  "${PROFILE_DIR}/GrShaderCache" \
  "${PROFILE_DIR}/GPUCache" 2>/dev/null || true

check_http_ready() {
  if command -v curl >/dev/null 2>&1; then
    curl -fsS --max-time 2 "${APP_URL}" >/dev/null 2>&1
    return $?
  fi

  if command -v wget >/dev/null 2>&1; then
    wget -q -T 2 -O /dev/null "${APP_URL}" >/dev/null 2>&1
    return $?
  fi

  # Fallback sem dependencias externas: abre conexao TCP com host/porta da URL.
  local without_scheme hostport host port
  without_scheme="${APP_URL#http://}"
  without_scheme="${without_scheme#https://}"
  hostport="${without_scheme%%/*}"
  host="${hostport%%:*}"
  port="${hostport##*:}"

  if [[ "${host}" == "${port}" ]]; then
    if [[ "${APP_URL}" == https://* ]]; then
      port="443"
    else
      port="80"
    fi
  fi

  if exec 3<>"/dev/tcp/${host}/${port}"; then
    exec 3>&-
    exec 3<&-
    return 0
  fi

  return 1
}

wait_for_http() {
  local max_wait_sec="${KIOSK_HTTP_WAIT_SEC:-45}"
  local attempt=0

  until check_http_ready; do
    attempt=$((attempt + 1))
    if [[ "${attempt}" -eq 1 ]]; then
      echo "[INFO] Aguardando servidor HTTP ficar disponivel em ${APP_URL}..." >&2
    fi

    if [[ "${attempt}" -ge "${max_wait_sec}" ]]; then
      echo "[WARN] Servidor ainda indisponivel apos ${max_wait_sec}s. Continuando espera ate responder..." >&2
      attempt=0
    fi
    sleep 1
  done
}

wait_for_http

# Aguarda o servidor X da sessao grafica ficar pronto.
for _ in {1..20}; do
  if xset -q >/dev/null 2>&1; then
    break
  fi
  sleep 0.5
done

if command -v xset >/dev/null 2>&1; then
  xset -dpms || true
  xset s off || true
  xset s noblank || true
fi

# Esconde cursor para uso touch/fullscreen no kiosk
"${UNCLUTTER_BIN}" --timeout 1 --ignore-scrolling &

# Em --kiosk, o Chromium usa fullscreen na resolucao do display.
# Mantemos 800x480 como fallback para execucoes sem kiosk.
"${CHROMIUM_BIN}" --kiosk "${APP_URL}" \
  --no-sandbox \
  --disable-gpu \
  --disable-service-worker \
  --disable-http-cache \
  --disable-translate \
  --disable-features=Translate,TranslateUI \
  --user-data-dir="${PROFILE_DIR}" \
  --disable-application-cache \
  --disk-cache-dir=/tmp/chromium-cache \
  --disk-cache-size=1 \
  --window-position=0,0 \
  --no-first-run --noerrdialogs --disable-infobars \
  --disable-pinch --overscroll-history-navigation=0
